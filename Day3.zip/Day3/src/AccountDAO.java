
public interface AccountDAO 
{
	boolean saveAccount(Account a);
	Account findAccount(int accountNo);
}
