
public class AccountDAOImpl implements AccountDAO {
    static Account[] arr=new Account[2];
	@Override
	
	public Account findAccount(int accountNo) {
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i].getAccountNo()==accountNo)
			{
				return arr[i];
			}
			
		}
			
		return null;
	}

	@Override
	public boolean saveAccount(Account a) {
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==null)
			{
				arr[i]=a;
				System.out.println(arr[i]);
				return true;
			}
		}
		return false;
	}

}
